//
// Created by Alex on 2018-10-29.
// Copyright (c) 2018 Sum & Substance. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SSEngine;

@interface SSFacade : NSObject

+ (SSEngine *)setupForApplicant:(NSString *)applicantID
                      withToken:(NSString *)token
                         locale:(NSString *)locale
                   supportEmail:(NSString *)supportEmail
                        baseUrl:(NSString *)baseUrl;

+ (UINavigationController *)getChatControllerWithAttributedTitle:(nullable NSAttributedString *)title;

@end
