//
//  SSLiveness3D.h
//  SumSubstanceKYC
//
//  Created by Sergey Kokunov on 02/09/2019.
//  Copyright © 2019 Sum & Substance. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SSLiveness3DThemeProtocol.h"

@class SSLiveness3D;

typedef NS_ENUM(NSInteger, SSLiveness3DStatus) {
    SSLiveness3DStatus_Cancelled,
    SSLiveness3DStatus_InitializationFailed,
    SSLiveness3DStatus_CameraPermissionDenied,
    SSLiveness3DStatus_TokenIsInvalid,
    SSLiveness3DStatus_VerificationPassedSuccessfully,
};

NS_ASSUME_NONNULL_BEGIN

typedef void(^SSLiveness3DTokenExpirationHandler)(void(^completionHandler)(NSString * __nullable newToken));
typedef void(^SSLiveness3DCompletionHandler)(UIViewController *controller, SSLiveness3DStatus status);
typedef NSString * __nullable(^SSLiveness3DTextHandler)(NSString *key, NSString *locale);
typedef UIImage * __nullable(^SSLiveness3DImageHandler)(NSString *key);

#pragma mark -

@interface SSLiveness3D : NSObject

+ (NSString *)descriptionForStatus:(SSLiveness3DStatus)status;

@property (nonatomic, copy) NSString * __nullable applicantId;

@property (nonatomic, copy) SSLiveness3DTextHandler __nullable textHandler;
@property (nonatomic, copy) SSLiveness3DImageHandler __nullable imageHandler;
@property (nonatomic) id<SSLiveness3DThemeProtocol> theme;

- (instancetype)initWithBaseUrl:(NSString *)baseUrl
                          token:(NSString *)token
                         locale:(NSString *)locale
         tokenExpirationHandler:(SSLiveness3DTokenExpirationHandler)tokenExpirationHandler
              completionHandler:(SSLiveness3DCompletionHandler)completionHandler;

- (UIViewController *)getController;

@end

NS_ASSUME_NONNULL_END
