//
// Created by Alex Katsz on 2018-10-29.
// Copyright (c) 2018 Octopod LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SSEngine;

@interface SSFacade : NSObject

+ (SSEngine *)setupForApplicant:(NSString *)applicantID
                      withToken:(NSString *)token
                         locale:(NSString *)locale
                   supportEmail:(NSString *)supportEmail
                      socketUrl:(NSString *)socketUrl
                        restUrl:(NSString *)restUrl;

+ (UINavigationController *)getChatControllerWithAttributedTitle:(nullable NSAttributedString *)title;

@end
