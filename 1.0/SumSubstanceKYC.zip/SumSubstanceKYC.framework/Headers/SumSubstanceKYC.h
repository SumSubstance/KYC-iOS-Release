//
//  SumSubstanceKYC.h
//  SumSubstanceKYC
//
//  Created by Alex Katsz on 25/12/2018.
//  Copyright © 2018 Octopod LLC. All rights reserved.
//

#import <SumSubstanceKYC/SSFacade.h>
#import <SumSubstanceKYC/SSEngine.h>


