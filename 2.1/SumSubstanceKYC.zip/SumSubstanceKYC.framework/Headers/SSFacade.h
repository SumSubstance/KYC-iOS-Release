//
// Created by Alex on 2018-10-29.
// Copyright (c) 2018 Sum & Substance. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SSEngine;
@class KYCColorConfig;
@class KYCImageConfig;

@interface SSFacade : NSObject

+ (SSEngine *)setupForApplicant:(NSString *)applicantID
                      withToken:(NSString *)token
                         locale:(NSString *)locale
                   supportEmail:(NSString *)supportEmail
                        baseUrl:(NSString *)baseUrl
                    colorConfig:(nullable __kindof KYCColorConfig *)colorConfig
                    imageConfig:(nullable __kindof KYCImageConfig *)imageConfig;

+ (UINavigationController *)getChatControllerWithAttributedTitle:(nullable NSAttributedString *)title;

@end
