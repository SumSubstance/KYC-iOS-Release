//
// Created by Alex on 2018-10-29.
// Copyright (c) 2018 Sum & Substance. All rights reserved.
//

#import <Foundation/Foundation.h>

@class SSAttachmentScenario;

@interface SSEngine : NSObject

+ (instancetype)instance;

- (void)connectWithExpirationHandler:(void (^)(void))tokenExpirationHandler verificationResultHandler:(void (^)(bool verified))verificationResultHandler;

- (void)setRefreshToken:(NSString *)newToken;

- (void)shutdown;

@end
