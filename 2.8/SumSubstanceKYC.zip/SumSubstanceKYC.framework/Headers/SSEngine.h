//
// Created by Alex on 2018-10-29.
// Copyright (c) 2018 Sum & Substance. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SSEngine : NSObject

/*!
 Called when the engine fails to find the remotely configured localization for a localizable key.
 
 Note: always happens for new applicants with the key "status_connecting" and possibly "status_waiting_for_network" until socket is connected
 */
@property (nonatomic) NSString * __nullable(^ __nullable onMissedLocalizedText)(NSString *key, NSString * __nullable lang, NSString *locale);


+ (instancetype)instance;

- (void)connectWithExpirationHandler:(void (^)(void))tokenExpirationHandler
           verificationResultHandler:(void (^)(bool verified))verificationResultHandler;

- (void)setRefreshToken:(NSString *)newToken;

- (void)shutdown;

@end

NS_ASSUME_NONNULL_END
