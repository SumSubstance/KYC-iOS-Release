#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "YYTextContainerView.h"
#import "YYTextDebugOption.h"
#import "YYTextEffectWindow.h"
#import "YYTextInput.h"
#import "YYTextKeyboardManager.h"
#import "YYTextLayout.h"
#import "YYTextLine.h"
#import "YYTextMagnifier.h"
#import "YYTextSelectionView.h"
#import "YYTextArchiver.h"
#import "YYTextAttribute.h"
#import "YYTextParser.h"
#import "YYTextRubyAnnotation.h"
#import "YYTextRunDelegate.h"
#import "NSAttributedString+YYText.h"
#import "NSParagraphStyle+YYText.h"
#import "UIPasteboard+YYText.h"
#import "UIView+YYText.h"
#import "YYTextAsyncLayer.h"
#import "YYTextTransaction.h"
#import "YYTextUtilities.h"
#import "YYTextWeakProxy.h"
#import "YYLabel.h"
#import "YYText.h"
#import "YYTextView.h"

FOUNDATION_EXPORT double YYTextVersionNumber;
FOUNDATION_EXPORT const unsigned char YYTextVersionString[];

