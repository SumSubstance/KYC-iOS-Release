//
//  RKManagedObjectStore_Private.h
//  RestKit
//
//  Created by Alexander Edge on 03/08/2016.
//  Copyright © 2016 RestKit. All rights reserved.
//

#import <Foundation/Foundation.h>

NSSet <NSManagedObjectID *> *RKSetOfManagedObjectIDsFromManagedObjectContextDidSaveNotification(NSNotification *notification);
