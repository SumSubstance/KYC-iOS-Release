//
//  ZoomAuthenticationHybrid.h
//  ZoomAuthenticationHybrid
//
//  Copyright © 2018 FaceTec. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ZoomAuthenticationHybrid.
FOUNDATION_EXPORT double ZoomAuthenticationHybridVersionNumber;

//! Project version string for ZoomAuthenticationHybrid.
FOUNDATION_EXPORT const unsigned char ZoomAuthenticationHybridVersionString[];

#import "ZoomPublicApi.h"
