//
//  SSActionEventInfo.h
//  SumSubstanceKYC
//
//  Copyright © 2019 Sum & Substance. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SSActionEventInfo : NSObject

@property (nonatomic, readonly) NSString * __nullable flowStep;

@end
