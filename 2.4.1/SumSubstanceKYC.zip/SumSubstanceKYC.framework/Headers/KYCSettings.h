//
//  KYCSettings.h
//  SumSubstanceKYC
//
//  Created by Sergey Kokunov on 11.04.2019.
//  Copyright © 2019 Sum & Substance. All rights reserved.
//

#import <Foundation/Foundation.h>

@class KYCSettings_Document;

NS_ASSUME_NONNULL_BEGIN

@interface KYCSettings : NSObject <NSCoding>

/*!
 Document settings
 */
@property (nonatomic, readonly) KYCSettings_Document *document;

/*!
 Creates an instance populated with default settings
 @param configure an optional block that takes the created instance as a parameter and give a chance to modify the settings before return
 @return KYCSettings object
 */
+ (instancetype _Nullable)create:(void(^ _Nullable)(KYCSettings * _Nullable settings))configure;

@end

#pragma mark -

@interface KYCSettings_Document : NSObject <NSCoding>

/*!
 Disables document auto capture (default is NO)
 */
@property (nonatomic, getter=isAutoCaptureDisabled) BOOL autoCaptureDisabled;

@end


NS_ASSUME_NONNULL_END
