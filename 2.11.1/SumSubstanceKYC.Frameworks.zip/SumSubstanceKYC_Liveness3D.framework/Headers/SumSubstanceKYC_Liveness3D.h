//
//  SumSubstanceKYC_Liveness3D.h
//  SumSubstanceKYC_Liveness3D
//
//  Copyright © 2018 Sum & Substance. All rights reserved.
//

#import "SSLiveness3D.h"
