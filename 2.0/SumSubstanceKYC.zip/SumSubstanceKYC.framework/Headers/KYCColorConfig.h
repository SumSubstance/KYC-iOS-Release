//  KYCColorConfig.h

#import <Foundation/Foundation.h>

@interface KYCColorConfig : NSObject

- (void)configureStart;

#pragma mark - Base Colors
- (UIColor *)alertPositive;
- (UIColor *)alertNegative;
- (UIColor *)supportContainerBg;
- (UIColor *)fragmentTitleBg;
- (UIColor *)fragmentTitleText;
- (UIColor *)navigationIconsColor;
- (UIColor *)searchHint;
- (UIColor *)searchText;
- (UIColor *)divider;

#pragma mark - Chat Colors
- (UIColor *)messageDayText; /// ?
- (UIColor *)messageServerDefaultBg;
- (UIColor *)messageServerDefaultText;
- (UIColor *)messageServerDefaultTime;
- (UIColor *)messageServerAcceptedBg;
- (UIColor *)messageServerAcceptedText;
- (UIColor *)messageServerAcceptedTime;
- (UIColor *)messageServerDeclinedText;
- (UIColor *)messageServerDeclinedIcon; /// ?
- (UIColor *)messageClientBg;
- (UIColor *)messageClientText;
- (UIColor *)messageClientTime;
- (UIColor *)messageStatusIcon; /// ?
- (UIColor *)messageFileTime; /// ?
- (UIColor *)messageFileOverlay; /// ?
- (UIColor *)messageFileStatusIcon; /// ?
- (UIColor *)messageLink;
- (UIColor *)messageButtonBg;
- (UIColor *)messageButtonText;
- (UIColor *)messageLoadingText; /// ?

#pragma mark - File Scenario Colors
- (UIColor *)buttonNextBg;
- (UIColor *)buttonNextText;
- (UIColor *)buttonNextIcon;
- (UIColor *)buttonRetakeBg;
- (UIColor *)buttonRetakeText;

- (UIColor *)buttonRetakeIcon;
- (UIColor *)buttonCancelText;
- (UIColor *)uploadProgressBg;
- (UIColor *)instructionText; /// ?
- (UIColor *)instructionFrame; /// ?
- (UIColor *)cameraCancelText;
- (UIColor *)cameraHintText;
- (UIColor *)photoOverlayBg; /// ?
- (UIColor *)videoOverlayBg; /// ?

- (UIColor *)videoLandmarks;

- (UIColor *)videoCoverBg;
- (UIColor *)videoReadText;
- (UIColor *)videoFaceNotDetected;
- (UIColor *)videoFaceDetected;
- (UIColor *)videoPrepareRecording;
- (UIColor *)videoFrame;

#pragma mark - Picker Scenario Colors
- (UIColor *)pickerHeaderBg;
- (UIColor *)pickerHeaderText;
- (UIColor *)pickerItemBg; /// ?
- (UIColor *)pickerItemText;
- (UIColor *)pickerClearColor; /// ?

#pragma mark - Web View Colors
- (UIColor *)webviewGotItBg;
- (UIColor *)webviewGotItHighlighted;
- (UIColor *)webviewGotItText;
- (UIColor *)webviewGotItIcon;

#pragma mark - Support Colors
- (UIColor *)supportSubtitle;
- (UIColor *)supportText;
- (UIColor *)supportIcon;

@end

