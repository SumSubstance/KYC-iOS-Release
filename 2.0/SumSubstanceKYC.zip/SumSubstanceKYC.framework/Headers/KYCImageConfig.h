//  KYCImageConfig.h

#import <Foundation/Foundation.h>

@interface KYCImageConfig : NSObject

/*
* bubbleIn - screen messages, background default incoming message
* bubbleInGreen - screen messages, background accepted incoming message
* bubbleOut - screen messages, background default outgoing message
* buttonBackground - default background for button with state normal
* buttonPressed - default background for button with state highlighted
* cameraButtonInner - now not used (red circle)
* cameraButtonOuter - background button video record
* cameraBig - background button take photo
* cameraButton - central content (attachment) button take photo
* flashOff - screen video, photo. button flash mode off
* flashOn - screen video, photo. button flash mode on
* phoneRotateToLandscape - scan document, background image with request phone rotate to landscape
* phoneRotateToPortrait - scan document, background image with request phone rotate to portrait
* declinedIcon - screen messages, image title in accepted incoming
* emailIcon - support screen, image left address email
* gotItTick - screen web, icon in right side button accept
* messageRead - image delivery status, finished
* messageSending - image delivery status, processing
* playButton - images in buttons play preview (screen messages, result video/photo) if playable
* accept - image in button next/done/accept or etc.
* retake - image in button retake preview photo
* serverAvatar - screen messages, image near incoming messages
* static_face - now not used (white smile in black background)
* supportIcon - background button for support screen
*
*/
- (nullable UIImage *)imageForNamed:(NSString *)name;

@end
