//
//  SumSubstanceKYC.h
//  SumSubstanceKYC
//
//  Created by Alex on 25/12/2018.
//  Copyright © 2018 Sum & Substance. All rights reserved.
//

#import <SumSubstanceKYC/SSFacade.h>
#import <SumSubstanceKYC/SSEngine.h>
#import <SumSubstanceKYC/KYCColorConfig.h>
#import <SumSubstanceKYC/KYCImageConfig.h>


